<?php

	require('fpdf/fpdf.php');
	$pdf = new FPDF('P','pt','A4');

	$pdf->SetTitle('Mala Direta');
	$pdf->SetAuthor('Augusto e Rafaela Silva');
	$pdf->SetCreator('php'.phpversion());
	$pdf->SetKeywords('php','pdf');
	$pdf->SetSubject('Aula de WEB');
	$pdf->AddPage();
	
	//definir a fonte
	$pdf->SetFont('Arial','','12');
	$pdf->Text(0,12,'x1');
	//espaçamento vertical
	$pdf->Ln(20);
	$pdf->SetFont('Courier','B','16');
	$pdf->SetTextColor(50,50,100);
	$pdf->SetY(70);
	$pdf->SetX(260);

	$titulo = 'Prezado(a) Srº(a)';
	$titulo = utf8_decode($titulo);
	$pdf->Write(30,$titulo);
	$pdf->Ln(30);	
	$txt = 'Neste mês de aniversário, nossa loja está com promoções imperdíveis e selecionadas especialmente para você. Não perca essa oportunidade de realizar bons negócios. Faça-nos uma visita. Cordialmente, Augusto & Rafaela Silva Gerente Comercial';
	$txt = utf8_decode($txt);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('times','B',14);
	$pdf->Write(20,$txt);

	$pdf->Output();
	
?>

