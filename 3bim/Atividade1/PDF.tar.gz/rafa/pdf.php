<?php

	require('fpdf/fpdf.php');
	require_once 'init.php';
 	$PDO = db_connect();
 	$sql = "SELECT nomeCliente FROM clientes ORDER BY nomeCliente ASC";
 
 	$stmt= $PDO->prepare($sql);	
 	$stmt->execute();

	$pdf = new FPDF('P','pt','A4');

	$pdf->SetTitle('Mala Direta');
	$pdf->SetAuthor('Augusto e Rafaela Silva');
	$pdf->SetCreator('php'.phpversion());
	$pdf->SetKeywords('php','pdf');
	$pdf->SetSubject('Aula de WEB');
	while($cliente = $stmt->fetch(PDO::FETCH_ASSOC)){
	$pdf->AddPage();

	

	
	//definir a fonte
	$pdf->SetFont('Arial','','12');
	//$pdf->Text(0,12,'x1');
	//espaçamento vertical
	$pdf->Ln(20);
	$pdf->SetFont('Arial','','12');
	$pdf->SetTextColor('#ffff');
	$pdf->SetY(70);
	$pdf->SetX(260);

     $Data = 'Varginha, '.date("d/m/Y");
     $Data = utf8_decode($Data);
     $pdf->Write(50,$Data);
     $pdf->Ln(50);
     $pdf->SetX(30);

	$titulo = 'Prezado(a) Sr(a) '.$cliente['nomeCliente'];
	$titulo = utf8_decode($titulo);
	$pdf->Write(50,$titulo);
	$pdf->Ln(50);
	$pdf->SetX(40);
	
	$txt = 'Neste mês de aniversário, nossa loja está com promoções imperdíveis e selecionadas especialmente para você.'; 
    $txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);	
	$pdf->SetX(40);
	
	$txt = 'Não perca essa oportunidade de realizar bons negócios.';
    $txt = utf8_decode($txt);
	$pdf->Write(15,$txt);		
	$pdf->Ln(15);
	$pdf->SetX(40);


	$txt = 'Faça-nos uma visita.';
    $txt = utf8_decode($txt);
	$pdf->Write(15,$txt);		
	$pdf->Ln(15);
	$pdf->SetX(30);


	$txt = 'Cordialmente,';
    $txt = utf8_decode($txt);
	$pdf->Write(100,$txt);	
	$pdf->Ln(100);
    $pdf->SetX(250);

	$nome = 'Augusto';
	$nome = utf8_decode($nome);
	$pdf->Write(15,$nome);
	$pdf->Ln(15);
	$pdf->SetX(220);

	$nome = 'Gerente Comercial';
	$nome = utf8_decode($nome);
	$pdf->Write(15,$nome);
	$pdf->Ln(15);
	
	
	}

	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('times','B',14);	
	
	$pdf->Output();
	
?>

