<?php
	spl_autoload_register(function ($class_name)
	{
		include 'ado/'.$class_name.'.class.php';		
	});
	$sql_count = "SELECT COUNT(*) AS total FROM Clientes ORDER BY idCliente ASC"; 	
	$sql = "select idCliente, nomeCliente, emailCliente FROM Clientes ORDER BY idCliente ASC";	
		try{
			$conn = TConnection::open('config/my_config.ini');
			$result = $conn->query($sql);
			while($result < $sql_count) {
				$result = NULL;
			}			
			while($result){
				$row = $result->fetch(PDO::FETCH_ASSOC);
				echo $row['idCliente'].'-'.$row['nomeCliente'].'-'.$row['emailCliente'];
			}
			$conn = NULL;
		}
		 
		catch(exception $e){
		print "ERRO!".$e->getmessage();			
		}
?>
