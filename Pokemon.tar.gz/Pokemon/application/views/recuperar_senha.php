<!doctype html>
	<html>
		<head>
			<meta charset="utf-8">
			<title>Lojão do Terceirão</title>
		</head>
		<body>
			<h2>Lojão do Terceirão</h2>
			<h3>Recuperação de cadastro</h3>
			<p>Olá: <?php echo $nome . " " . $sobrenome ?>.</p>
			<p>Você solicitou a senha de acesso ao website.</p>
			<p>Sua senha é: <?php echo $senha ?></p>
			<h4>Seja bem-vindo de volta e boas compras!<br>
			<h4>Lojão do Terceirão</h4>
		</body>
	</html>
