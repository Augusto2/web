<div id="homebody">
	<div class="alinhado-centro borda-base espaco-vertical">
		<h3>Seja Bem-Vindo à nossa loja.</h3>
		<p>Use o formulário abaixo para se cadastrar.</p>
	</div>
	<div class="row-fluid">
		<?php
			echo validation_errors();
			echo form_open(base_url('cadastro/adicionar'),array('id'=>'form_cadastro')) . 
				 "<div class='span4'>" .
				 form_input(array('id'=>'nome','name'=>'nome','Placeholder'=>'Nome',
		 		 'value'=>set_value('nome'))) .				 
				 form_input(array('id'=>'email','name'=>'email','Placeholder'=>'E-mail',
				 'value'=>set_value('email'))) .
				 form_password(array('id'=>'senha','name'=>'senha','Placeholder'=>'Senha',
				 'value'=>set_value('senha'))) .
				 form_submit('btn_cadastrar','Cadastrar') .
				 "</div>" .
				 form_close();
		?>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){	
	$('#data_captura').mask('00/00/0000',{reverse: true });	
	});
</script> 
