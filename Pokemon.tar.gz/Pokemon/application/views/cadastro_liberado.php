<div id="homebody">
	<div class="alinhado-centro borda-base espaco-vertical">
		<h3>Cadastro confirmado.</h3>
		<p>Você já está apto para fazer compras.</p>
	</div>
	<div class="row-fluid">
		<p>Seu cadastro foi confirmado com sucesso.<br/>
			Você já pode fazer compras. <br/>
		<a href="<?php echo base_url(’produtos’) ?>">Ver os produtos da loja.</a></p>
	</div>
</div>
