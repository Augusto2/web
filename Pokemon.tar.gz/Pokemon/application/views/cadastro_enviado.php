<div id="homebody">
	<div class="alinhado-centro borda-base espaço-vertical">
		<h3>Seja Bem-Vindo à nossa loja.</h3>
		<p>Dados de cadastro recebidos.</p>
	</div>
	<div class="row-fluid">
		<p>Seu cadastro foi efetuado com sucesso.<br/>
			Você receberá um email para ativação da sua conta. <br/>
			Caso não receba a mensagem em alguns minutos, cheque também a pasta SPAM da sua conta de email.<br/>
			Muito obrigado por se cadastrar.</p>
	</div>
</div> 
