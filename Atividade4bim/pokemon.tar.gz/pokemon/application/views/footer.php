<div class ="alinhado-centro borda-base espaco-vertical">
    <div id="footer" class="borda-topo espaco-vertical">
        <?php echo date("Y"); ?> - Augusto Bastos
    </div>
</div>
