<div class="input-group">
    <form class="form-horizontal">
        <fieldset>
            <div class ="alinhado-centro borda-base espaco-vertical">              
                <h3>Editar</h3>               
            </div>

            <div class="dropdown">
                <label class="input-group">Mudar o tipo:</label>						
                <select data-toggle="dropdown" id="tipo_pokemon" name="tipo_pokemon" class="btn btn-danger dropdown-toggle" required=""><span class="caret"></span>
                    <ul class="dropdown-menu">
                        <option value="" disabled selected hidden>Tipo: </option>
                        <option value="Verde">Verde</option>
                        <option value="Laranja">Laranja</option>
                        <option value="Vermelho">Vermelho</option>
                    </ul>
                </select>
            </div>
            <br>
            <div class="form-group">               
                <div class="col-sm-12 controls">
                    <button type="submit" href="#" class="btn btn-primary"><i class="fa fa-sign-in"></i>Editar</button>
                </div>
            </div>   		
		</fieldset>
	</form>
</div>


