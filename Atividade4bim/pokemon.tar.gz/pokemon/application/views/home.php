<div id="homebody">
    <h2></h2>
    <div class ="alinhado-centro borda-base espaco-vertical">
    </div>
    <div class="row-fluid">
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Tipo</th>
                    <th>Data de Captura</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>

                <tr class="danger">
                    <?php
                    foreach ($pokemon as $info) {
                        echo "<tr>" . 
							 "<td>" . $info->nome . "</td>" .
                       		 "<td>" . $info->tipo_pokemon . "</td>" .
                        	 "<td>" . $info->data_captura . "</td>" .
                         	 "<td><a href='http://localhost/pokemon/index.php/Editar'><button type='submit' class='btn btn-default'>Editar</button></a></td>" .
                         	 "<td><a><button type='submit' class='btn btn-default'>Excluir</button></a></td>";
                    }
                    ?>
                </tr>
            </tbody>
        </table>
		<img src="http://localhost/pokemon/assets/img/pok.png">
    </div>
</div>
</div>

