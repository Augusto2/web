<div class="container">
    <div class ="masthead">		
        <nav class="navbar navbar-default navbar-fixed-top">
         	<ul class="nav navbar-nav">		
                <li class="active"><a href="http://localhost/pokemon/index.php/Home"><h3>Pokémon <span class="label label-warning">GO</span></h3><br></a></li>    
                <ul class="nav navbar-nav navbar-right">
                 	<?php echo "<li><a>Olá " . $this->session->userdata('usuario')->nome . " " . "</a></li>"?>
                    <li><a href="http://localhost/pokemon/index.php/Login/logout">Sair</a></li>
                </ul>
            </ul>
        </nav>
		<br><br><br><br><br><br>
    </div>
